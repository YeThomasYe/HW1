package com.example.proj1;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.Timer;
import java.util.TimerTask;

public class MapsActivity extends AppCompatActivity implements
        GoogleMap.OnMyLocationButtonClickListener,
        GoogleMap.OnMyLocationClickListener,
        SensorEventListener,
        OnMapReadyCallback,
        ActivityCompat.OnRequestPermissionsResultCallback {

    private GoogleMap mMap;
    protected LocationManager locationManager;
    private boolean loc_gps;
    private boolean loc_network;
    private LatLng oldpos;
    private SensorManager sensorManager;
    private Sensor orientationSensor;
    private int mygrid = 18;
    private static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATES = 1;
    //設定超過一個距離(尺)他就會做更新location的動作
    private static final long MINIMUM_TIME_BETWEEN_UPDATES = 1000;
    //設定超過一個時間(毫秒)他就會做更新location的動作

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    //private boolean permissionDenied = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        orientationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Button simuvibra = findViewById(R.id.btnSimuVibra);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        simuvibra.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                bt_click();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)

    protected void bt_click() {
        Log.d("##", "simulator clicked");
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            enableMyLocation();
        }
        Location location = null;
        if (loc_gps) {
            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        } else if (loc_network) {
            location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }

        if (location == null) {
            Log.d("##", "null location");
        } else {
            Log.d("##", location.toString());
            MarkerOptions markerOpt = new MarkerOptions();
            final LatLng mylocation = new LatLng(location.getLatitude(), location.getLongitude());
            markerOpt.position(mylocation);
            markerOpt.title("偵測到路不平");
            markerOpt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW));
            mMap.addMarker(markerOpt).showInfoWindow();
            PolylineOptions polylineOpt = new PolylineOptions();
            polylineOpt.add(mylocation);
            polylineOpt.add(oldpos);
            polylineOpt.color(Color.BLUE);
            Polyline polyline = mMap.addPolyline(polylineOpt);
            polyline.setWidth(5);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mylocation, mygrid));
            oldpos = mylocation;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, orientationSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);
        enableMyLocation();

        Toast.makeText(this, "hello map", Toast.LENGTH_SHORT).show();
        // Add a marker in EC and move the camera
        final LatLng ec = new LatLng(24.7869954, 120.997482);
        oldpos = ec;
        mMap.addMarker(new MarkerOptions().position(ec).title("初始位置"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ec, mygrid));

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(
                //Provider: the name of the GPS provider
                LocationManager.GPS_PROVIDER,
                //minTime: 最小時間間隔後更新位置，以毫秒為單位
                MINIMUM_TIME_BETWEEN_UPDATES,
                //minDistance: 最短距離間隔外更新位置，以公尺為單位
                MINIMUM_DISTANCE_CHANGE_FOR_UPDATES,
                //Listener:每次地點更新時會呼叫LocationListener中onLocationChanged(Location)方法
                MyLocationListener
        );
        locationManager.requestLocationUpdates(
                //Provider: the name of the GPS provider
                LocationManager.NETWORK_PROVIDER,
                //minTime: 最小時間間隔後更新位置，以毫秒為單位
                MINIMUM_TIME_BETWEEN_UPDATES,
                //minDistance: 最短距離間隔外更新位置，以公尺為單位
                MINIMUM_DISTANCE_CHANGE_FOR_UPDATES,
                //Listener:每次地點更新時會呼叫LocationListener中onLocationChanged(Location)方法
                MyLocationListener
        );

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "require permission 0", Toast.LENGTH_SHORT).show();
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            enableMyLocation();
//            return;
        }
        try{
            Location gpslocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (gpslocation != null){
                loc_gps = true;
            }
        } catch(Exception e){
            Log.d("##", "gps location fail");
            loc_gps = false;
        }
        try{
            Location networklocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (networklocation != null){
                loc_network = true;
            }
        } catch(Exception e){
            Log.d("##", "gps location fail");
            loc_network = false;
        }
        Boolean initLocation = true;

        new Timer().scheduleAtFixedRate(new TimerTask(){
//            oldpos = ec;
            @Override
            public void run(){
                runOnUiThread(new Runnable()
                {
                    public void run()
                    {
                        Log.d("##", "A Kiss every 10 seconds");

                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            enableMyLocation();
                        }
                        Location location = null;
                        if (loc_gps){
                            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        } else if (loc_network){
                            location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        }

                        if (location == null) {
                            Log.d("##", "null location");
                        } else {
                            Log.d("##",location.toString());
//                    Toast.makeText(this, "show place", Toast.LENGTH_SHORT).show();
                            MarkerOptions markerOpt = new MarkerOptions();
                            final LatLng mylocation = new LatLng(location.getLatitude(), location.getLongitude());
                            markerOpt.position(mylocation);
                            markerOpt.title("現在位置");
                            markerOpt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)); mMap.addMarker(markerOpt).showInfoWindow();
                            PolylineOptions polylineOpt = new PolylineOptions();
                            polylineOpt.add(mylocation);
                            polylineOpt.add(oldpos);
                            polylineOpt.color(Color.BLUE);
                            Polyline polyline = mMap.addPolyline(polylineOpt);
                            polyline.setWidth(5);
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mylocation,mygrid));
                            oldpos = mylocation;
                        }
                    }
                });
            }
        },1000,10000);
    }

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            // Permission to access the location is missing. Show rationale and request permission
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onSensorChanged(SensorEvent event) {
        float z = event.values[2];
        if (Math.abs(z)>5)
        {
            bt_click();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    //private class MyLocationListener implements LocationListener {
    LocationListener MyLocationListener = new  LocationListener(){
        @Override
        public void onLocationChanged(Location location) {
        }
        @Override
        public void onProviderDisabled(String provider) {
        }
        @Override
        public void onProviderEnabled(String provider) {
        }
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    };
}
